@echo off
REM Start the Ollama-compatible proxy on port 11434
REM Assumes you already started llama-server (OpenAI-compatible) on http://127.0.0.1:8000/v1

cd /d "%~dp0"
python ollama_proxy.py --host 127.0.0.1 --port 11434 --config models.json

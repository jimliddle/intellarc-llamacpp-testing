#!/usr/bin/env python3
"""
Ollama-compatible proxy that forwards requests to one or more OpenAI-compatible backends
(e.g., llama.cpp llama-server) and exposes common Ollama endpoints:
  - GET  /api/tags
  - POST /api/generate
  - POST /api/chat
  - POST /api/embeddings
  - GET  /api/version

Designed for minimal dependencies (standard library only).

How it works
------------
- You define models in a JSON config file (default: models.json).
- Each model maps to an OpenAI-compatible base URL (ending with /v1) and an upstream model id.
- The proxy translates Ollama request/response shapes (including streaming) to/from OpenAI.

Streaming
---------
Ollama streams NDJSON lines. OpenAI streams SSE ("data: {...}\\n\\n").
This proxy converts SSE deltas into NDJSON chunks.

Limitations
-----------
- Tool-calls / function-calls are passed through best-effort (message content only for streaming).
- Some Ollama-specific fields (eval_count, etc.) are approximated if upstream exposes timings.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
import uuid
import urllib.parse
import http.client
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
from typing import Any, Dict, Optional, Tuple


def _now_rfc3339() -> str:
    # Ollama uses RFC3339-like timestamps
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime()) + "Z"


def _read_json(handler: BaseHTTPRequestHandler) -> Dict[str, Any]:
    length = int(handler.headers.get("content-length", "0") or "0")
    raw = handler.rfile.read(length) if length > 0 else b""
    if not raw:
        return {}
    try:
        return json.loads(raw.decode("utf-8"))
    except Exception as e:
        raise ValueError(f"Invalid JSON body: {e}")


def _send_json(handler: BaseHTTPRequestHandler, code: int, obj: Any) -> None:
    data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
    handler.send_response(code)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(data)))
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Access-Control-Allow-Origin", "*")
    handler.end_headers()
    handler.wfile.write(data)


def _send_ndjson_headers(handler: BaseHTTPRequestHandler) -> None:
    handler.send_response(200)
    handler.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Connection", "keep-alive")
    handler.send_header("Access-Control-Allow-Origin", "*")
    handler.end_headers()


def _ndjson_write(handler: BaseHTTPRequestHandler, obj: Any) -> None:
    line = (json.dumps(obj, ensure_ascii=False) + "\n").encode("utf-8")
    handler.wfile.write(line)
    handler.wfile.flush()


def _parse_base_url(url: str) -> Tuple[str, str, int, str]:
    """
    Returns (scheme, host, port, base_path)
    where base_path includes any path prefix (e.g. "/v1").
    """
    u = urllib.parse.urlparse(url)
    if u.scheme not in ("http", "https"):
        raise ValueError(f"Unsupported URL scheme: {u.scheme}")
    host = u.hostname or ""
    port = u.port or (443 if u.scheme == "https" else 80)
    base_path = u.path.rstrip("/")
    return u.scheme, host, port, base_path


def _http_conn(scheme: str, host: str, port: int):
    if scheme == "https":
        return http.client.HTTPSConnection(host, port, timeout=600)
    return http.client.HTTPConnection(host, port, timeout=600)


class ModelRegistry:
    def __init__(self, config_path: str):
        self.config_path = config_path
        self._cfg: Dict[str, Any] = {}
        self.reload()

    def reload(self) -> None:
        with open(self.config_path, "r", encoding="utf-8") as f:
            self._cfg = json.load(f)
        if "models" not in self._cfg or not isinstance(self._cfg["models"], list):
            raise ValueError("Config must contain a top-level 'models' list")

    def list_models(self) -> list[Dict[str, Any]]:
        return self._cfg.get("models", [])

    def get(self, name: str) -> Optional[Dict[str, Any]]:
        for m in self.list_models():
            if m.get("name") == name:
                return m
        return None

    def default(self) -> Dict[str, Any]:
        d = self._cfg.get("default_model")
        if d:
            m = self.get(d)
            if m:
                return m
        # fallback to first model
        models = self.list_models()
        if not models:
            raise ValueError("No models configured")
        return models[0]


def _openai_request(
    base_url: str,
    path: str,
    method: str,
    headers: Dict[str, str],
    body: Optional[bytes],
) -> http.client.HTTPResponse:
    scheme, host, port, base_path = _parse_base_url(base_url)
    conn = _http_conn(scheme, host, port)
    full_path = f"{base_path}{path}"
    conn.request(method, full_path, body=body, headers=headers)
    return conn.getresponse()


def _collect_response(resp: http.client.HTTPResponse) -> Tuple[int, Dict[str, str], bytes]:
    status = resp.status
    headers = {k.lower(): v for k, v in resp.getheaders()}
    data = resp.read()
    return status, headers, data


def _best_effort_extract_text_from_openai(payload: Dict[str, Any]) -> str:
    # chat.completions non-stream response
    try:
        choice = payload.get("choices", [{}])[0]
        msg = choice.get("message") or {}
        return msg.get("content") or ""
    except Exception:
        return ""


def _best_effort_extract_text_from_openai_completion(payload: Dict[str, Any]) -> str:
    try:
        choice = payload.get("choices", [{}])[0]
        text = choice.get("text")
        if isinstance(text, str):
            return text
        msg = choice.get("message") or {}
        return msg.get("content") or ""
    except Exception:
        return ""


def _ollama_error(handler: BaseHTTPRequestHandler, code: int, message: str) -> None:
    _send_json(handler, code, {"error": message})


class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True


class OllamaProxyHandler(BaseHTTPRequestHandler):
    server_version = "ollama-proxy/0.1"

    # Injected at server init:
    registry: ModelRegistry  # type: ignore

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type,Authorization")
        self.end_headers()

    def do_GET(self):
        try:
            if self.path.startswith("/api/tags"):
                return self._handle_tags()
            if self.path.startswith("/api/version"):
                return _send_json(self, 200, {"version": "ollama-proxy-0.1"})
            if self.path.startswith("/health") or self.path == "/":
                return _send_json(self, 200, {"status": "ok"})
            return _ollama_error(self, 404, f"Unknown GET {self.path}")
        except Exception as e:
            return _ollama_error(self, 500, str(e))

    def do_POST(self):
        try:
            if self.path.startswith("/api/generate"):
                return self._handle_generate()
            if self.path.startswith("/api/chat"):
                return self._handle_chat()
            if self.path.startswith("/api/embeddings"):
                return self._handle_embeddings()
            # Some clients use /api/embed (older)
            if self.path.startswith("/api/embed"):
                return self._handle_embeddings()
            return _ollama_error(self, 404, f"Unknown POST {self.path}")
        except ValueError as ve:
            return _ollama_error(self, 400, str(ve))
        except Exception as e:
            return _ollama_error(self, 500, str(e))

    def _handle_tags(self):
        models = []
        for m in self.registry.list_models():
            name = m.get("name")
            # Provide Ollama-like metadata; many clients only need name.
            models.append({
                "name": name,
                "model": name,
                "modified_at": m.get("modified_at", _now_rfc3339()),
                "size": int(m.get("size", 0)),
                "digest": m.get("digest", "sha256:" + uuid.uuid4().hex),
                "details": {
                    "format": "gguf",
                    "family": m.get("family", ""),
                    "parameter_size": m.get("parameter_size", ""),
                    "quantization_level": m.get("quantization_level", ""),
                }
            })
        return _send_json(self, 200, {"models": models})

    def _select_model(self, requested: Optional[str]) -> Dict[str, Any]:
        if requested:
            m = self.registry.get(requested)
            if m:
                return m
        return self.registry.default()

    def _handle_generate(self):
        req = _read_json(self)
        requested_model = req.get("model")
        model = self._select_model(requested_model)
        base_url = model["base_url"]
        upstream_model = model.get("upstream_model", "local")

        prompt = req.get("prompt", "")
        stream = req.get("stream", True)
        options = req.get("options", {}) or {}

        # Map a few common Ollama options to OpenAI-like params
        temperature = options.get("temperature", req.get("temperature", 0.8))
        top_p = options.get("top_p", req.get("top_p", 0.95))
        max_tokens = options.get("num_predict", req.get("max_tokens"))

        if stream:
            return self._stream_openai_chat_as_generate(
                base_url=base_url,
                upstream_model=upstream_model,
                prompt=prompt,
                temperature=temperature,
                top_p=top_p,
                max_tokens=max_tokens,
                model_name=model.get("name", requested_model or upstream_model),
            )
        else:
            payload = {
                "model": upstream_model,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": temperature,
                "top_p": top_p,
                "stream": False,
            }
            if max_tokens is not None:
                payload["max_tokens"] = int(max_tokens)
            status, _, data = _collect_response(_openai_request(
                base_url,
                "/chat/completions",
                "POST",
                headers={"Content-Type": "application/json", "Authorization": "Bearer local"},
                body=json.dumps(payload).encode("utf-8"),
            ))
            if status >= 400:
                return _ollama_error(self, status, data.decode("utf-8", errors="ignore"))
            resp = json.loads(data.decode("utf-8"))
            text = _best_effort_extract_text_from_openai(resp)
            out = {
                "model": model.get("name", requested_model or upstream_model),
                "created_at": _now_rfc3339(),
                "response": text,
                "done": True,
            }
            # Attach timing if present
            if "timings" in resp:
                out["timings"] = resp["timings"]
            return _send_json(self, 200, out)

    def _handle_chat(self):
        req = _read_json(self)
        requested_model = req.get("model")
        model = self._select_model(requested_model)
        base_url = model["base_url"]
        upstream_model = model.get("upstream_model", "local")

        messages = req.get("messages", [])
        stream = req.get("stream", True)
        options = req.get("options", {}) or {}

        temperature = options.get("temperature", req.get("temperature", 0.8))
        top_p = options.get("top_p", req.get("top_p", 0.95))
        max_tokens = options.get("num_predict", req.get("max_tokens"))

        if stream:
            return self._stream_openai_chat_as_ollama_chat(
                base_url=base_url,
                upstream_model=upstream_model,
                messages=messages,
                temperature=temperature,
                top_p=top_p,
                max_tokens=max_tokens,
                model_name=model.get("name", requested_model or upstream_model),
            )
        else:
            payload = {
                "model": upstream_model,
                "messages": messages,
                "temperature": temperature,
                "top_p": top_p,
                "stream": False,
            }
            if max_tokens is not None:
                payload["max_tokens"] = int(max_tokens)

            status, _, data = _collect_response(_openai_request(
                base_url,
                "/chat/completions",
                "POST",
                headers={"Content-Type": "application/json", "Authorization": "Bearer local"},
                body=json.dumps(payload).encode("utf-8"),
            ))
            if status >= 400:
                return _ollama_error(self, status, data.decode("utf-8", errors="ignore"))
            resp = json.loads(data.decode("utf-8"))
            text = _best_effort_extract_text_from_openai(resp)
            out = {
                "model": model.get("name", requested_model or upstream_model),
                "created_at": _now_rfc3339(),
                "message": {"role": "assistant", "content": text},
                "done": True,
            }
            if "timings" in resp:
                out["timings"] = resp["timings"]
            return _send_json(self, 200, out)

    def _handle_embeddings(self):
        req = _read_json(self)
        requested_model = req.get("model")
        model = self._select_model(requested_model)
        base_url = model["base_url"]
        upstream_model = model.get("upstream_model", "local")

        prompt = req.get("prompt") or req.get("input") or ""
        payload = {
            "model": upstream_model,
            "input": prompt,
        }
        status, _, data = _collect_response(_openai_request(
            base_url,
            "/embeddings",
            "POST",
            headers={"Content-Type": "application/json", "Authorization": "Bearer local"},
            body=json.dumps(payload).encode("utf-8"),
        ))
        if status >= 400:
            return _ollama_error(self, status, data.decode("utf-8", errors="ignore"))
        resp = json.loads(data.decode("utf-8"))
        # OpenAI embeddings returns data[0].embedding
        emb = None
        try:
            emb = resp["data"][0]["embedding"]
        except Exception:
            emb = resp.get("embedding")
        return _send_json(self, 200, {"embedding": emb})

    def _stream_openai_chat_as_ollama_chat(
        self,
        base_url: str,
        upstream_model: str,
        messages: list,
        temperature: float,
        top_p: float,
        max_tokens: Optional[int],
        model_name: str,
    ):
        payload = {
            "model": upstream_model,
            "messages": messages,
            "temperature": temperature,
            "top_p": top_p,
            "stream": True,
        }
        if max_tokens is not None:
            payload["max_tokens"] = int(max_tokens)

        resp = _openai_request(
            base_url,
            "/chat/completions",
            "POST",
            headers={
                "Content-Type": "application/json",
                "Accept": "text/event-stream",
                "Authorization": "Bearer local",
            },
            body=json.dumps(payload).encode("utf-8"),
        )
        if resp.status >= 400:
            status, _, data = _collect_response(resp)
            return _ollama_error(self, status, data.decode("utf-8", errors="ignore"))

        _send_ndjson_headers(self)
        created_at = _now_rfc3339()

        # Parse SSE lines: "data: {...}" or "data: [DONE]"
        buffer = b""
        done_sent = False
        while True:
            chunk = resp.read(1024)
            if not chunk:
                break
            buffer += chunk
            while b"\n" in buffer:
                line, buffer = buffer.split(b"\n", 1)
                line = line.strip()
                if not line:
                    continue
                if not line.startswith(b"data:"):
                    continue
                data_part = line[len(b"data:"):].strip()
                if data_part == b"[DONE]":
                    if not done_sent:
                        _ndjson_write(self, {
                            "model": model_name,
                            "created_at": created_at,
                            "message": {"role": "assistant", "content": ""},
                            "done": True,
                        })
                        done_sent = True
                    continue
                try:
                    evt = json.loads(data_part.decode("utf-8", errors="ignore"))
                except Exception:
                    continue
                # Extract delta content
                delta = ""
                try:
                    delta = evt["choices"][0].get("delta", {}).get("content") or ""
                except Exception:
                    delta = ""

                if delta:
                    _ndjson_write(self, {
                        "model": model_name,
                        "created_at": created_at,
                        "message": {"role": "assistant", "content": delta},
                        "done": False,
                    })

        if not done_sent:
            _ndjson_write(self, {
                "model": model_name,
                "created_at": created_at,
                "message": {"role": "assistant", "content": ""},
                "done": True,
            })

    def _stream_openai_chat_as_generate(
        self,
        base_url: str,
        upstream_model: str,
        prompt: str,
        temperature: float,
        top_p: float,
        max_tokens: Optional[int],
        model_name: str,
    ):
        payload = {
            "model": upstream_model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": temperature,
            "top_p": top_p,
            "stream": True,
        }
        if max_tokens is not None:
            payload["max_tokens"] = int(max_tokens)

        resp = _openai_request(
            base_url,
            "/chat/completions",
            "POST",
            headers={
                "Content-Type": "application/json",
                "Accept": "text/event-stream",
                "Authorization": "Bearer local",
            },
            body=json.dumps(payload).encode("utf-8"),
        )
        if resp.status >= 400:
            status, _, data = _collect_response(resp)
            return _ollama_error(self, status, data.decode("utf-8", errors="ignore"))

        _send_ndjson_headers(self)
        created_at = _now_rfc3339()
        buffer = b""
        done_sent = False

        while True:
            chunk = resp.read(1024)
            if not chunk:
                break
            buffer += chunk
            while b"\n" in buffer:
                line, buffer = buffer.split(b"\n", 1)
                line = line.strip()
                if not line:
                    continue
                if not line.startswith(b"data:"):
                    continue
                data_part = line[len(b"data:"):].strip()
                if data_part == b"[DONE]":
                    if not done_sent:
                        _ndjson_write(self, {
                            "model": model_name,
                            "created_at": created_at,
                            "response": "",
                            "done": True,
                        })
                        done_sent = True
                    continue
                try:
                    evt = json.loads(data_part.decode("utf-8", errors="ignore"))
                except Exception:
                    continue
                delta = ""
                try:
                    delta = evt["choices"][0].get("delta", {}).get("content") or ""
                except Exception:
                    delta = ""

                if delta:
                    _ndjson_write(self, {
                        "model": model_name,
                        "created_at": created_at,
                        "response": delta,
                        "done": False,
                    })

        if not done_sent:
            _ndjson_write(self, {
                "model": model_name,
                "created_at": created_at,
                "response": "",
                "done": True,
            })

    def log_message(self, fmt: str, *args) -> None:
        # quieter logs; comment out to enable
        sys.stderr.write("%s - - [%s] %s\n" % (self.address_string(), self.log_date_time_string(), fmt % args))


def main():
    ap = argparse.ArgumentParser(description="Ollama-compatible proxy for OpenAI-compatible backends (llama-server, etc.)")
    ap.add_argument("--host", default="127.0.0.1", help="Host to bind (default: 127.0.0.1)")
    ap.add_argument("--port", type=int, default=11434, help="Port to bind (default: 11434)")
    ap.add_argument("--config", default="models.json", help="Path to models.json (default: models.json)")
    args = ap.parse_args()

    registry = ModelRegistry(args.config)

    # attach registry to handler class
    OllamaProxyHandler.registry = registry  # type: ignore

    httpd = ThreadingHTTPServer((args.host, args.port), OllamaProxyHandler)
    print(f"Ollama proxy listening on http://{args.host}:{args.port}")
    print(f"Using config: {args.config}")
    print("Endpoints: /api/tags /api/chat /api/generate /api/embeddings")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
